

<?php $__env->startSection('alterar_senha'); ?>

<form class="form-signin" method="post" action="<?php echo e(('/modificar/senha/empresa')); ?>">

    <div class="text-center">
        <h2 class="form-signin-heading">ALTERAR SENHA</h2>
        <hr>
        <span>Preencha os campos abaixo para cadastrar uma nova senha</span>
    </div>
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <input type="hidden" name="email" value="<?php echo session('empresa') ?>" >
        <label for="formGroupExampleInput" class="form-label">*Nova senha</label>
        <input type="password" class="form-control form-control" name="newsenha" placeholder="Digite sua nova senha" />
    </div>
    <div class="mb-3">
        <label for="formGroupExampleInput" class="form-label">*Confirmar nova senha</label>
        <input type="password" class="form-control form-control" name="confsenha" placeholder="Digite confirme sua senha"  />
    </div>
    <div class="d-grid gap-2">
        <input type="submit" class="btn-primary btn-lg" name="alterarsenha" value="Alterar Senha">
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.alterar_senha_empresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cdl\cdl\resources\views/alterar_senha_empresa.blade.php ENDPATH**/ ?>