

<?php $__env->startSection('home_empresa'); ?>

<form class="row g-3">

    <input type="text" class="form-control" id="pesquisar" placeholder="Cargo, experiência ou Palavra Chave">
    <button type="button" class="btn btn-primary">BUSCAR CANDUDATOS</button>

    </form>
 
 
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layout.home_emp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cdl\cdl\resources\views/home_emp.blade.php ENDPATH**/ ?>