@extends('layout.home_emp')

@section('home_empresa')

<form class="row g-3">

    <input type="text" class="form-control" id="pesquisar" placeholder="Cargo, experiência ou Palavra Chave">
    <button type="button" class="btn btn-primary">BUSCAR CANDUDATOS</button>

    </form>
 
 
@endsection
        